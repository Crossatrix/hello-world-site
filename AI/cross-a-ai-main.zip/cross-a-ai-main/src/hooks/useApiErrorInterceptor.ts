import { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { isDevModeEnabled } from "./useDevMode";

export const useApiErrorInterceptor = () => {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const originalFetch = window.fetch;

    window.fetch = async (...args: Parameters<typeof fetch>) => {
      const response = await originalFetch(...args);

      const url = typeof args[0] === "string" ? args[0] : args[0] instanceof Request ? args[0].url : "";
      const isApiCall = url.includes("supabase") || url.includes("functions") || url.includes("lovable");
      
      // Exclude 406 (PostgREST "no rows" for .single()) as it's handled in app logic
      if (isApiCall && response.status >= 400 && response.status !== 406 && location.pathname !== "/error" && location.pathname !== "/banned" && isDevModeEnabled()) {
        const cloned = response.clone();
        let bodyText: string;
        try {
          bodyText = await cloned.text();
        } catch {
          bodyText = '{"error":"Could not read response body"}';
        }

        navigate("/error", {
          state: {
            statusCode: response.status,
            responseBody: bodyText,
            url: url,
          },
          replace: false,
        });
      }

      return response;
    };

    return () => {
      window.fetch = originalFetch;
    };
  }, [navigate, location.pathname]);
};
